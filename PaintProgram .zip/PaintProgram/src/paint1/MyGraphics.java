
package paint1;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JComponent;

//In this class we have all the methods that let the user to paint.

public class MyGraphics extends JComponent {

    private static final long serialVersionUID = 1L;
    private int n;
    public int LX;
    public int LY;
    public Color Color;
    public Color BGColor;
    boolean Brush;
    public int type=3;
    boolean Goma = false;
    boolean Shape = false;
    int Shapetype=1;
    int xf;
    int yf;
    boolean shapeswitch = false;
    boolean turns = false;
    Graphics2D gs;
    Graphics2D gd;
    Graphics2D gn;
    boolean Spray=false;
    boolean Pen=true;
    int scale=10;
    Color ColorSh;

    MyGraphics() {
        setPreferredSize(new Dimension(1, 1));
    }
    
    public void initGraphics (Graphics g) {
        gs = (Graphics2D) g;
        gd = (Graphics2D) g;
    }
    
    public void paintComponent1(Graphics g, int x, int y) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color);
        g2.setStroke(new BasicStroke(type));
        g2.draw(new Line2D.Float(x, y, LX, LY));
        repaint();
        LX = x;
        LY = y;

    }
    
     public void paintPen(Graphics g, int x, int y) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color);
        g2.setStroke(new BasicStroke(1));
        g2.draw(new Line2D.Float(x, y, LX, LY));
        repaint();
        LX = x;
        LY = y;

    }
    
        public void paintComponentSp(Graphics g, int x, int y) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        int ax=x+2;
        int bx=x+4;
        int cx=x+6;
        int axn=x-2;
        int bxn=x-4;
        int cxn=x-6;
        int ay=y+2;
        int by=y+4;
        int cy=y+6;
        int ayn=y-2;
        int byn=y-4;
        int cyn=y-6;
        int dx=x+13;
        int dxn=x-13;
        int dy=y+13;
        int dyn=y-13;
        g2.setColor(Color);
        g2.setStroke(new BasicStroke(type));
        g2.draw(new Line2D.Float(ax, by, ax-1, by-1));
        g2.draw(new Line2D.Float(bx, ay, bx-1, ay-1));
        g2.draw(new Line2D.Float(bx, by, bx-1, by-1));
        g2.draw(new Line2D.Float(ax, ay, ax-1, ay-1));
        g2.draw(new Line2D.Float(cx, by, cx-1, by-1));
        g2.draw(new Line2D.Float(cx, ay, cx-1, ay-1));
        g2.draw(new Line2D.Float(bx, ay, bx-1, ay-1));
        g2.draw(new Line2D.Float(axn, byn, axn-1, byn-1));
        g2.draw(new Line2D.Float(bxn, ayn, bxn-1, ayn-1));
        g2.draw(new Line2D.Float(cxn, byn, cxn-1, byn-1));
        g2.draw(new Line2D.Float(axn, ayn, axn-1, ayn-1));
        g2.draw(new Line2D.Float(cxn, byn, cxn-1, byn-1));
        g2.draw(new Line2D.Float(cxn, ayn, cxn-1, ayn-1));
        g2.draw(new Line2D.Float(bxn, ayn, bxn-1, ayn-1));
        g2.draw(new Line2D.Float(dxn, ayn, dxn-1, ayn-1));
        g2.draw(new Line2D.Float(dx, byn, dx-1, byn-1));
        g2.draw(new Line2D.Float(cxn, dyn, cxn-1, dyn-1));
        g2.draw(new Line2D.Float(cxn, dy, bxn-1, dy-1));
         g2.draw(new Line2D.Float(ax, by, ax-1, by-1));
        g2.draw(new Line2D.Float(bxn, ay, bxn-1, ay-1));
        g2.draw(new Line2D.Float(bxn, by, bxn-1, by-1));
        g2.draw(new Line2D.Float(axn, ay, axn-1, ay-1));
        g2.draw(new Line2D.Float(cxn, by, cxn-1, by-1));
        g2.draw(new Line2D.Float(cxn, ay, cxn-1, ay-1));
        g2.draw(new Line2D.Float(bxn, ay, bxn-1, ay-1));
        g2.draw(new Line2D.Float(axn, by, axn-1, by-1));
        g2.draw(new Line2D.Float(bxn, cy, bxn-1, cy-1));
        g2.draw(new Line2D.Float(cxn, by, cxn-1, by-1));
        g2.draw(new Line2D.Float(axn, ay, axn-1, ay-1));
        g2.draw(new Line2D.Float(cxn, by, cxn-1, by-1));
        g2.draw(new Line2D.Float(cxn, ay, cxn-1, ay-1));
        g2.draw(new Line2D.Float(bxn, cy, bxn-1, cy-1));
        g2.draw(new Line2D.Float(dxn, ay, dxn-1, ay-1));

        repaint();

    }

    public void eraseComponent(Graphics g, int x, int y) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(BGColor);
        g2.setStroke(new BasicStroke(type));
        g2.draw(new Line2D.Float(x, y, LX, LY));
        repaint();
        LX = x;
        LY = y;

    }

    public void paintComponent2(Graphics g, int x, int y) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(type));
        g2.draw(new Line2D.Float(x, y, LX, LY));
        g2.setColor(Color);
        repaint();
        LX = x;
        LY = y;

    }

    public void paintShapeSq(Graphics g, int x, int y) {

        super.paintComponent(g);
        gd=(Graphics2D) g.create();
        gs=(Graphics2D) g.create();
        gn=(Graphics2D) g.create();
        if ((LX!=x) && (LY !=y)){
        
        gd.setStroke(new BasicStroke(type));
        gs.setStroke(new BasicStroke(type));
         gn.setStroke(new BasicStroke(type));
        
        gd.setColor(BGColor);
        gd.fillRect(xf, yf, (LX-xf), (LY-yf));
        gd.draw(new Rectangle2D.Double(xf,yf, LX-xf, LY-yf));
        /*gd.draw(new Line2D.Double(xf+(LX-xf), yf, LX, LY));
        gd.draw(new Line2D.Double(xf, yf+(LY-yf), LX, LY));
        if (LX>x) {
        gd.draw(new Line2D.Double(xf+x, yf, LX, yf));
        }
        if (LY>y){
        gd.draw(new Line2D.Double(xf, yf+y, xf, LY));
        }*/
        gs.setColor(Color);
        
        gn.setColor(ColorSh);
        gn.fillRect(xf, yf, (x-xf), (y-yf));
        gs.draw(new Rectangle2D.Double(xf, yf, x-xf, y-yf));
        LX=x;
        LY=y;
        }
        }
    
    public void paintShapeOval(Graphics g, int x, int y) {

        super.paintComponent(g);
        gd=(Graphics2D) g.create();
        gs=(Graphics2D) g.create();
        gn=(Graphics2D) g.create();
        if ((LX!=x) && (LY !=y)){
        
        gd.setStroke(new BasicStroke(type));
        gs.setStroke(new BasicStroke(type));
         gn.setStroke(new BasicStroke(type));
        
        gd.setColor(BGColor);
        gd.fillOval(xf, yf, (LX-xf), (LY-yf));
        gd.draw(new Ellipse2D.Double(xf,yf, LX-xf, LY-yf));
        /*gd.draw(new Line2D.Double(xf+(LX-xf), yf, LX, LY));
        gd.draw(new Line2D.Double(xf, yf+(LY-yf), LX, LY));
        if (LX>x) {
        gd.draw(new Line2D.Double(xf+x, yf, LX, yf));
        }
        if (LY>y){
        gd.draw(new Line2D.Double(xf, yf+y, xf, LY));
        }*/
        gs.setColor(Color);
        gs.draw(new Ellipse2D.Double(xf, yf, x-xf, y-yf));
        gn.setColor(ColorSh);
        gn.fillOval(xf, yf, (x-xf), (y-yf));
        LX=x;
        LY=y;
        }
        }

        

    

    public void eraseShape(Graphics g, int x, int y) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(type));
        g2.draw(new Rectangle2D.Double(LX, LY, x, y));
        g2.setColor(BGColor);
        repaint();
    }


    public void setLX(int LX) {
        this.LX = LX;
    }

    public void setLY(int LY) {
        this.LY = LY;
    }

    public void resetline(Graphics g, int x, int y) {
        LX = x;
        LY = y;

    }

    public void SetType(int a) {
        type = a;
    }
    
      public int getScale() {
            return scale;
        }
      
      public void setScale(int value) {
            if (value != scale) {
                int old = scale;
                this.scale = value;
                firePropertyChange("scale", old, scale);
                repaint();
            }
        }


}

