package paint1;

/*
This is the source code of the Paint & More 1.0 application.
This program is a beta and in future upgrades will be implemented new functions that currently
cannot be accessed.
These functions are described in the SRS as WON'T requirements. 

Developers:
    Daniel Ruiz Bustos
    Marcos Ruiz Muñoz
    Jose Luis Sierra Benito
    Carlos González Valtierra
    Javier Méndez García-Brioles

Software engineering URJC 2019
Metodología de la programación

 */
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import program.welcome;

public class Mousetest1 {

    public static void main(String[] args) throws InterruptedException {
        welcome w = new welcome();
        w.setVisible(true);
        Thread.sleep(7000);
        MyGraphics G = new MyGraphics();
        mouse m = new mouse(G);
        m.setVisible(true);

    }

}

class mouse extends JFrame {

    int Lang = 0;

    public mouse(final MyGraphics G) {
        this.setLocationRelativeTo(null);
        this.setTitle("Paint & More");
        this.setIconImage(new ImageIcon(getClass().getResource("/Images/icon.png")).getImage());

        final String MmEsp1 = "Archivo";
        final String MmEsp2 = "Inicio";
        final String MmEsp3 = "Ver";
        final String FEsp1 = "Nuevo";
        final String FEsp2 = "Abrir";
        final String FEsp3 = "Guardar";
        final String FEsp4 = "Deshacer";
        final String FEsp5 = "Rehacer";
        final String HEsp1 = "Herramientas";
        final String HEsp2 = "Formas";
        final String HEsp3 = "Colores";
        final String HEsp4 = "Portapapeles";
        final String TEsp1 = "Lápiz";
        final String TEsp2 = "Pincel";
        final String TEsp3 = "Spray";
        final String TEsp4 = "Borrador";
        final String TEsp5 = "Color de Fondo";
        final String TEsp6 = "Grosor";
        final String SEsp1 = "Nuevo Óvalo";
        final String SEsp2 = "Nuevo Rectángulo";
        final String CEsp1 = "Líneas";
        final String CEsp2 = "Fondo de las Formas";
        final String ClEsp1 = "Copiar";
        final String ClEsp2 = "Cortar";
        final String ClEsp3 = "Pegar";
        final String VREsp1 = "Zoom";
        final String VREsp2 = "Pantalla completa";
        final String VREsp3 = "Seleccionar tamaño";
        final String OthEsp1 = "No implementado aún";
        final String OthEsp2 = "Cambiar Color de Fondo";
        final String OthEsp3 = "Cambiar Color de Formas";
        final String OthEsp4 = "Cambiar Color de Línea";
        final String OthEsp5 = "<html><h1><b>Instrucciones</b></h1><html><p>1. Operación no implementada quiere decir que aún no está disponible esa opción</p> <p>2. Para acceder a las distintas herramientas utiliza el menú Home </p><p>3. Puedes cambiar el grosor del pincel en el menú así como el de otros trazos, pero el pincel tiene siempre el mismo grosor</p><p>4. La opción color de fondo camabia el color de fondo, sin embargo, <u>borrará cualquier cosa dibujada en pantalla, por lo tanto es recomendable usarlo siempre al principio</u></p><p>5. Para crear una forma debes pulsar el botón 'Nueva Forma'. <u>Cada vez que quieras crear una nueva forma</u></p><p>6. Dibujar y modificar el tamaño de una forma con el cursor <u>sobreescribirá y borrará todo lo que haya debajo de esta</u>, por lo tanto hay que tener cuidado al usarlo</p><p>7. Color de forma cambia el color del fondo de la forma mientras que color de línea cambia el color de las líneas que dibuja, incluyendo las líneas que delimitan el borde de una forma</p>";
        final String OthEsp6 = "Ayuda";
        final String OthEsp7 = "Idioma";
        final String OthEsp8 = "Instrucciones";

        final String MmEng1 = "File";
        final String MmEng2 = "Home";
        final String MmEng3 = "See";
        final String FEng1 = "New";
        final String FEng2 = "Open";
        final String FEng3 = "Save";
        final String FEng4 = "Undo";
        final String FEng5 = "Redo";
        final String HEng1 = "Tools";
        final String HEng2 = "Shapes";
        final String HEng3 = "Colors";
        final String HEng4 = "Clipboard";
        final String TEng1 = "Pencil";
        final String TEng2 = "Brush";
        final String TEng3 = "Spray";
        final String TEng4 = "Eraser";
        final String TEng5 = "Background Color";
        final String TEng6 = "Thickness";
        final String SEng1 = "New Oval";
        final String SEng2 = "New Rectangle";
        final String CEng1 = "Lines";
        final String CEng2 = "Shape Background";
        final String ClEng1 = "Copy";
        final String ClEng2 = "Cut";
        final String ClEng3 = "Paste";
        final String VREng1 = "Zoom";
        final String VREng2 = "Fullscreen";
        final String VREng3 = "Select size";
        final String OthEng1 = "Not Supported Yet";
        final String OthEng2 = "Change Background Color";
        final String OthEng3 = "Change Shape Color";
        final String OthEng4 = "Change Line Color";
        final String OthEng5 = "<html><h1><b>Instructions</b></h1><html><p>1. Not supported yet operations mean the operation is not implemented yet</p> <p>2. To use the different tools access the home menu </p><p>3. You can change the brush and other tool's thickness on the tools menu, however the pen has always the same thickness</p><p>4. Background color changes the color of the background, however, <u>it would erase everything drawn on screen so far, always use it before drawing anything</u></p><p>5. To create a shape you need to press the 'New Shape' button <u>each time you want to create a new shape</u></p><p>6. Drawing and resizing a shape with the mouse would <u>overwrite and erase everything below it</u>, so be careful when using it</p><p>7. Shape color changes the color of the shapes background while line color changes the color of the lines you draw, including a shape's outer lines</p>";
        final String OthEng6 = "Help";
        final String OthEng7 = "Language";
        final String OthEng8 = "Instructions";

        //We establish the names of the menu buttons in both Spanish and English
        String[] FileOpt = {FEng1, FEng2, FEng3, FEng4, FEng5};
        String[] FileOptM = {HEng1, HEng2, HEng3, HEng4};
        String[] ToolM = {TEng1, TEng2, TEng3, TEng4, TEng5, TEng6};
        String[] ToolMT = {"3", "5", "7", "10", "15", "20"};
        String[] ShapeM = {SEng1, SEng2};
        String[] ColorsM = {CEng1, CEng2};
        String[] ClipbM = {ClEng1, ClEng2, ClEng3};
        String[] SeeM = {VREng1, VREng2, VREng3};

        //We save the variables according to their functions in their corresponding array
        setLayout(new FlowLayout());
        setVisible(true);
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        final Container c = this.getContentPane();
        c.setBackground(Color.white);
        /* JLabel label1 = new JLabel();
        add(label1, BorderLayout.NORTH);
        JLabel label2 = new JLabel();
        add(label2, BorderLayout.NORTH);*/
        add(G);
        G.BGColor = Color.white;

        JMenuBar Menu = new JMenuBar(); //Create menu

        final JMenu File = new JMenu(MmEng1); //Create the file section

        final JMenuItem Mi = new JMenuItem(FileOpt[0]);
        final JMenuItem Mi1 = new JMenuItem(FileOpt[1]);
        final JMenuItem Mi2 = new JMenuItem(FileOpt[2]);
        final JMenuItem Mi3 = new JMenuItem(FileOpt[3]);
        final JMenuItem Mi4 = new JMenuItem(FileOpt[4]);
        File.add(Mi);
        File.add(Mi1);
        File.add(Mi2);
        File.add(Mi3);
        File.add(Mi4);

        //Insert new, open, save, undo, redo in file.
        //The application is still in beta and open, save, undo and redo are not implemented yet.
        Mi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                c.setBackground(Color.black);
                c.setBackground(Color.white);
                G.BGColor = Color.white;
            }
        });
        Mi1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });
        Mi2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });
        Mi3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });
        Mi4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });

        Menu.add(File); //Insert the section file in menu

        final JMenu Home = new JMenu(MmEng2); //Create Home

        //Create all the sections of Home and then set the corresponding functions of each section.
        //Once we have done all, we add each section to Home.
        final JMenu Tools = new JMenu(FileOptM[0]);
        final JMenu Shapes = new JMenu(FileOptM[1]);
        final JMenu Colors = new JMenu(FileOptM[2]);
        final JMenu Clipboard = new JMenu(FileOptM[3]);

        //We do the same with the sections of tools (create the section, specify its function and add it to tools)
        final JMenuItem T1 = new JMenuItem(ToolM[0]);
        final JMenuItem T2 = new JMenuItem(ToolM[1]);
        final JMenuItem T3 = new JMenuItem(ToolM[2]);
        final JMenuItem T4 = new JMenuItem(ToolM[3]);
        final JMenuItem T5 = new JMenuItem(ToolM[4]);
        final JMenu T6 = new JMenu(ToolM[5]);

        T1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.Pen = true;
                G.Brush = false;
                G.shapeswitch = false;
                G.Goma = false;
                G.Spray = false;
                G.Shape = false;
            }
        });

        Tools.add(T1);

        T2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.Pen = false;
                G.Brush = true;
                G.shapeswitch = false;
                G.Goma = false;
                G.Spray = false;
                G.Shape = false;
            }
        });

        Tools.add(T2);

        T3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.Pen = false;
                G.Brush = false;
                G.shapeswitch = false;
                G.Goma = false;
                G.Spray = true;
                G.Shape = false;
            }
        });

        Tools.add(T3);

        T4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.Pen = false;
                G.Brush = false;
                G.shapeswitch = false;
                G.Goma = true;
                G.Spray = false;
                G.Shape = false;
            }
        });

        Tools.add(T4);

        T5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent2) {
                Color inicolor = G.BGColor;
                Color Chosen = Color.WHITE;
                if (Lang == 0) {
                    Chosen = JColorChooser.showDialog(null, OthEng2,
                            inicolor);
                } else {
                    Chosen = JColorChooser.showDialog(null, OthEsp2,
                            inicolor);
                }
                if (Chosen != null) {
                    c.setBackground(Chosen);
                    G.BGColor = Chosen;
                }
            }
        });

        Tools.add(T5);

        //Insert the different values of thickness
        JMenuItem Tt1 = new JMenuItem(ToolMT[0]);
        JMenuItem Tt2 = new JMenuItem(ToolMT[1]);
        JMenuItem Tt3 = new JMenuItem(ToolMT[2]);
        JMenuItem Tt4 = new JMenuItem(ToolMT[3]);
        JMenuItem Tt5 = new JMenuItem(ToolMT[4]);
        JMenuItem Tt6 = new JMenuItem(ToolMT[5]);

        Tt1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.type = 3;
            }
        });

        Tt2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.type = 5;
            }
        });

        Tt3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.type = 7;
            }
        });

        Tt4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.type = 10;
            }
        });

        Tt5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.type = 15;
            }
        });

        Tt6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.type = 20;
            }
        });
        T6.add(Tt1);
        T6.add(Tt2);
        T6.add(Tt3);
        T6.add(Tt4);
        T6.add(Tt5);
        T6.add(Tt6);
        Tools.add(T6);

        Home.add(Tools);

        //Add Tools to Home
        final JMenuItem S1 = new JMenuItem(ShapeM[0]);
        final JMenuItem S2 = new JMenuItem(ShapeM[1]);

        S1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.Pen = false;
                G.Brush = false;
                G.shapeswitch = false;
                G.Goma = false;
                G.Spray = false;
                G.Shape = true;
                G.Shapetype = 2;
            }
        });

        Shapes.add(S1);

        S2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                G.Pen = false;
                G.Brush = false;
                G.shapeswitch = false;
                G.Goma = false;
                G.Spray = false;
                G.Shape = true;
                G.Shapetype = 1;
            }
        });

        Shapes.add(S2);

        //Add circle and square/rectangle to shapes
        //Add Shapes to Home
        Home.add(Shapes);

        final JMenuItem C1 = new JMenuItem(ColorsM[0]);
        final JMenuItem C2 = new JMenuItem(ColorsM[1]);

        C1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent2) {
                Color inicolor = G.Color;
                Color Chosen = Color.WHITE;
                if (Lang == 0) {
                    Chosen = JColorChooser.showDialog(null, OthEng4,
                            inicolor);
                } else {
                    Chosen = JColorChooser.showDialog(null, OthEsp4,
                            inicolor);
                }
                if (Chosen != null) {

                    G.Color = Chosen;
                }
            }

        });

        Colors.add(C1);

        C2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent2) {
                Color inicolor = G.Color;
                Color Chosen = Color.WHITE;
                if (Lang == 0) {
                    Chosen = JColorChooser.showDialog(null, OthEng3,
                            inicolor);
                } else {
                    Chosen = JColorChooser.showDialog(null, OthEsp3,
                            inicolor);
                }
                if (Chosen != null) {
                    G.ColorSh = Chosen;
                }
            }

        });

        Colors.add(C2);

        //Add lines and shape background to Colors
        //Add Colors to Home
        Home.add(Colors);

        final JMenuItem Cb1 = new JMenuItem(ClipbM[0]);
        final JMenuItem Cb2 = new JMenuItem(ClipbM[1]);
        final JMenuItem Cb3 = new JMenuItem(ClipbM[2]);

        Cb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });

        Clipboard.add(Cb1);

        Cb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });

        Clipboard.add(Cb2);

        Cb3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });

        Clipboard.add(Cb3);

        //Add copy, cut and paste to Clipboard
        //Add Clipboard to Home
        Home.add(Clipboard);

        Menu.add(Home); //Insert Home to Menu

        //We do the same with the section See
        final JMenu See = new JMenu(MmEng3);

        final JMenuItem SE1 = new JMenuItem(SeeM[0]);
        final JMenuItem SE2 = new JMenuItem(SeeM[1]);
        final JMenuItem SE3 = new JMenuItem(SeeM[2]);
        See.add(SE1);
        See.add(SE2);
        See.add(SE3);

        SE1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });
        SE2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });
        SE3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng1);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp1);
                }
            }
        });

        Menu.add(See); //Insert See in Menu

        final JMenu Help = new JMenu(OthEng6);
        final JMenuItem I1 = new JMenuItem(OthEng8);
        final JMenu I2 = new JMenu(OthEng7);
        I1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                if (Lang == 0) {
                    JOptionPane.showMessageDialog(null, OthEng5);
                } else {
                    JOptionPane.showMessageDialog(null, OthEsp5);
                }
            }
        });

        JMenuItem L0 = new JMenuItem("English");
        JMenuItem L1 = new JMenuItem("Español");

        //Depending on the language we put the variables in spanish or english.
        L0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                File.setText(MmEng1);
                Mi.setText(FEng1);
                Mi1.setText(FEng2);
                Mi2.setText(FEng3);
                Mi3.setText(FEng4);
                Mi4.setText(FEng5);
                Home.setText(MmEng2);
                Tools.setText(HEng1);
                Shapes.setText(HEng2);
                Colors.setText(HEng3);
                Clipboard.setText(HEng4);
                T1.setText(TEng1);
                T2.setText(TEng2);
                T3.setText(TEng3);
                T4.setText(TEng4);
                T5.setText(TEng5);
                T6.setText(TEng6);
                S1.setText(SEng1);
                S2.setText(SEng2);
                C1.setText(CEng1);
                C2.setText(CEng2);
                Cb1.setText(ClEng1);
                Cb2.setText(ClEng2);
                Cb3.setText(ClEng3);
                See.setText(MmEng3);
                SE1.setText(VREng1);
                SE2.setText(VREng2);
                SE3.setText(VREng3);
                Help.setText(OthEng6);
                I1.setText(OthEng8);
                I2.setText(OthEng7);
                Lang = 0;
            }
        });

        L1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent a1) {
                File.setText(MmEsp1);
                Mi.setText(FEsp1);
                Mi1.setText(FEsp2);
                Mi2.setText(FEsp3);
                Mi3.setText(FEsp4);
                Mi4.setText(FEsp5);
                Home.setText(MmEsp2);
                Tools.setText(HEsp1);
                Shapes.setText(HEsp2);
                Colors.setText(HEsp3);
                Clipboard.setText(HEsp4);
                T1.setText(TEsp1);
                T2.setText(TEsp2);
                T3.setText(TEsp3);
                T4.setText(TEsp4);
                T5.setText(TEsp5);
                T6.setText(TEsp6);
                S1.setText(SEsp1);
                S2.setText(SEsp2);
                C1.setText(CEsp1);
                C2.setText(CEsp2);
                Cb1.setText(ClEsp1);
                Cb2.setText(ClEsp2);
                Cb3.setText(ClEsp3);
                See.setText(MmEsp3);
                SE1.setText(VREsp1);
                SE2.setText(VREsp2);
                SE3.setText(VREsp3);
                Help.setText(OthEsp6);
                I1.setText(OthEsp8);
                I2.setText(OthEsp7);
                Lang = 1;
            }
        });
        I2.add(L0);
        I2.add(L1);

        //Add Instructions and language to Help
        //Add Help to Menu
        Help.add(I1);
        Help.add(I2);
        Menu.add(Help);

        setJMenuBar(Menu);
        G.repaint();
        int option;
        final Graphics g = this.getGraphics();
        G.initGraphics(g);

        addMouseMotionListener(new MouseAdapter() {

            public int GetX(MouseEvent e) {
                return e.getX();
            }

            public int GetY(MouseEvent e) {
                return e.getY();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                G.shapeswitch = true;
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                /* label1.setText("X=" + x + ";");
                label2.setText("Y=" + y);*/

            }

            @Override
            public void mouseMoved(MouseEvent e) {
                G.LX = e.getX();
                G.LY = e.getY();
            }

            @Override

            public void mouseDragged(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                /*label1.setText("X=" + x + ";");
                label2.setText("Y=" + y);*/
                if (G.Goma == true) {
                    G.eraseComponent(g, x, y);
                } else if (G.Shape == true) {
                    if (G.shapeswitch == false) {
                        G.xf = x;
                        G.yf = y;
                        G.shapeswitch = true;
                    } else if (G.shapeswitch == true) {
                        if (G.Shapetype == 2) {
                            G.paintShapeOval(g, x, y);
                        } else if (G.Shapetype == 1) {
                            G.paintShapeSq(g, x, y);
                        }
                    }
                } else if (G.Spray == true) {
                    G.paintComponentSp(g, x, y);
                } else if (G.Pen == true) {
                    G.paintPen(g, x, y);

                } else if (G.Brush == true) {
                    G.paintComponent1(g, x, y);
                }
            }
        });

    }

}
